<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Response;
use App\Models\User;
use App\Models\Note;
use Hash;
use Session;
use DB;

class CustomAuthController extends Controller
{
    public function login()
    {
        return view('login');
    }
    public function registration()
    {
        return view('registration');
    }
    public function show()
    {
        return view('view');
    }
    public function registerUser(Request $request)
    {
        $request->validate([
            'name' => 'required|regex:/^[A-Z]+$/i',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:5|max:12',
            'phone_number' => 'required|regex:/^[0-9]+$/i',
            'address' => 'required',
        ]);
        $user = new User();
        $note = new Note();
        $user->name = $request->name;
        $user->email = $request->email;
        $note->phone_number = $request->phone_number;
        $note->address = $request->address;
        $user->password = Hash::make($request->password);
        $request = $user->save();
        $request = $user->note()->save($note);
        if ($request) {
            return back()->with('success', 'you have registered successfully');
        } else {
            return back()->with('fail', 'something wrong');
        }
    }
    public function loginUser(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required|min:5|max:12',
        ]);
        $user = User::where('email', $request->email)->first();
        if ($user) {
            if (Hash::check($request->password, $user->password)) {
                $request->session()->put('loginId', $user->id);
                return redirect('dashboard');
            } else {
                return back()->with('fail', 'Password not matches.');
            }
        } else {
            return back()->with('fail', 'This email is not registered.');
        }
    }
    public function dashboard()
    {
        $data = array();


        if (Session::has('loginId')) {
            $data = User::with(['note'])->find(Session::get('loginId'));
        }
        return view('dashboard', compact('data'));
    }
    public function logout()
    {
        if (Session::has('loginId')) {
            Session::pull('loginId');
            return redirect('login');
        }
    }
    public function edit(Request $request)
    {
        $name = $request->input('name');
        $id = $request->input('id');
        $email = $request->input('email');
        $phone_number = $request->input('phone_number');
        $address = $request->input('address');
        DB::update('update users set name = ?,email=? where id = ?', [$name, $email, $id]);
        DB::update('update notes set address = ?,phone_number=? where id = ?', [$address, $phone_number, $id]);

        echo "Record updated successfully.<br/>";
        return redirect('dashboard');
    }
    public function index()
    {
        return view('home');
    }
    public function create(Request $request)
    {
        $user =  User::find(1);
        $note = new Note;
        $note->phone_number = $request->phone_number;
        $note->address = $request->address;
        $user->note()->save($note);
        return 'Saved';
    }
    public function update()
    {
        $user = User::find(1);
        $note = new Note;
        $note->phone_number = '7456';
        $note->address = 'asdffgh';
        $user->note()->update($note->toArray());
        return 'updated';
    }
    public function view()
    {
        $user = User::with('note')->whereId(1)->first();
        return Response::json($user);
    }
    public function destroy($id)
    {
        DB::delete('delete from users where id = ?',[$id]);
        DB::delete('delete from notes where id = ?',[$id]);
        echo "Record deleted successfully.";
        return redirect('dashboard');
    }
}
